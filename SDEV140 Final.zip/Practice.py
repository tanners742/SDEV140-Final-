import tkinter as tk
from tkinter import *
from PIL import ImageTk, Image

# creates second window for program
def main_clicked():
   window = tk.Toplevel()
   window.title("Quantity and Sauce")
   window.config(bg="red")

   type_frame = Frame(window, width=0, height=0)
   type_frame.grid(row=0, column=0, padx=10, pady=5)

# creates the labels for secondary window
   label_bar = Frame(type_frame, width=180, height=0, bg="white")
   label_bar.grid(row=0, column=0, padx=5, pady=5)
   Label(type_frame, text="Please make your selections.").grid(row=0, column=0, padx=5, pady=5)
   Label(window, text="Quantity:").grid(row=1, column=0, padx=5, pady=5)
   Label(window, text="sauce:").grid(row=2, column=0, padx=5, pady=5)

# creates quantity selection buttons
   eight = Button(window, text="8")
   eight.grid(row=1, column=1, padx=5, pady=5)

   sixteen = Button(window, text="16")
   sixteen.grid(row=1, column=2, padx=5, pady=5)

   twenty4 = Button(window, text="24")
   twenty4.grid(row=1, column=3, padx=5, pady=5)

# creates sauce selection buttons
   none = Button(window, text="None")
   none.grid(row=2, column=1, padx=5, pady=5)

   mild= Button(window, text="Mild")
   mild.grid(row=2, column=2, padx=5, pady=5)

   medium= Button(window, text="Medium")
   medium.grid(row=2, column=3, padx=5, pady=5)

   hot= Button(window, text="Hot")
   hot.grid(row=2, column=4, padx=5, pady=5)

   confirm = Button(window, text="confrim")
   confirm.grid(row=4, column=1, padx=0, pady=0)



#establishing main window for program
main = Tk()

main.title("Wing Ordering Site")
main.config(bg="red")


main_frame = Frame(main, width=600, height=600)
main_frame.grid(row=0, column=0, padx=10, pady=5)

label_bar = Frame(main_frame, width=200, height=50, bg="white")
label_bar.grid(row=2, column=0, padx=5, pady=5)

Label(main_frame, text="Wing Type").grid(row=1, column=0, padx=5, pady=5)

bonelessImg = ImageTk.PhotoImage(Image.open("../BonelessImg.jpg"))
label = Label(main_frame, image= bonelessImg)
label.grid(row=2, column=1)

bone_inImg = ImageTk.PhotoImage(Image.open("../Bone-InImg.jpg"))
label = Label(main_frame, image= bone_inImg)
label.grid(row=2, column=2)

bone_in = Button(main, text="Bone-In", command=main_clicked)
bone_in.grid(row=2, column=1, padx=5, pady=5)

boneless = Button(main, text="Boneless", command=main_clicked)
boneless.grid(row=2, column=0, padx=5, pady=5)


main.mainloop()


